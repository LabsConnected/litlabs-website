# Try known Acer download URLs for Nitro 5 AN515-54 ELAN driver
$headers = @{
    "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}

# Known Acer Nitro 5 AN515-54 driver package URLs
$urls = @(
    "https://global-download.acer.com/OSDriver/ELAN/ELAN_I2C/13.6.14.1/ELAN_I2C.zip",
    "https://global-download.acer.com/OSDriver/ELAN_I2C/13.6.14.1/ELAN_I2C.zip",
    "https://global-download.acer.com/OSDriver/TouchPad/ELAN/13.6.14.1/ELAN_I2C.zip",
    "https://global-download.acer.com/OSDriver/TouchPad_ELAN_I2C/13.6.14.1/TouchPad_ELAN_I2C.zip"
)

foreach ($url in $urls) {
    Write-Host "Trying: $url"
    try {
        $resp = Invoke-WebRequest -Uri $url -Headers $headers -UseBasicParsing -TimeoutSec 10
        if ($resp.StatusCode -eq 200) {
            $outPath = "C:\Users\litbi\acer_elan_driver.zip"
            [System.IO.File]::WriteAllBytes($outPath, $resp.Content)
            Write-Host "  DOWNLOADED to $outPath ($([math]::Round($resp.Content.Length/1MB, 1)) MB)"
        } else {
            Write-Host "  Status: $($resp.StatusCode)"
        }
    } catch {
        Write-Host "  Failed: $($_.Exception.Message)"
    }
}

# Also try to list the directory
Write-Host ""
Write-Host "Trying to list Acer driver directory..."
try {
    $resp = Invoke-WebRequest -Uri "https://global-download.acer.com/OSDriver/" -Headers $headers -UseBasicParsing -TimeoutSec 10
    $links = [regex]::Matches($resp.Content, 'href="([^"]*)"')
    $elanLinks = $links | Where-Object { $_.Groups[1].Value -match 'ELAN|TouchPad|Touch' }
    if ($elanLinks) {
        Write-Host "Found ELAN/TouchPad links:"
        $elanLinks | ForEach-Object { Write-Host "  $($_.Groups[1].Value)" }
    } else {
        Write-Host "No ELAN links found in directory listing"
        Write-Host "Available links:"
        $links | Select-Object -First 20 | ForEach-Object { Write-Host "  $($_.Groups[1].Value)" }
    }
} catch {
    Write-Host "Could not list directory: $($_.Exception.Message)"
}
