@echo off
chcp 65001 >nul
echo ========================================
echo NETWORK SPEED OPTIMIZATION
echo ========================================
echo.
echo [1/5] Disabling Nagle Algorithm (reduces latency)...
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" /v TcpAckFrequency /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" /v TCPNoDelay /t REG_DWORD /d 1 /f >nul 2>&1
echo Done.
echo.
echo [2/5] Optimizing DNS cache...
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v CacheHashTableBucketSize /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v CacheHashTableSize /t REG_DWORD /d 4 /f >nul 2>&1
ipconfig /flushdns >nul 2>&1
echo Done.
echo.
echo [3/5] Disabling bandwidth throttling...
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched" /v NonBestEffortLimit /t REG_DWORD /d 0 /f >nul 2>&1
echo Done.
echo.
echo [4/5] Optimizing network buffer sizes...
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v DefaultReceiveWindow /t REG_DWORD /d 65535 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v DefaultSendWindow /t REG_DWORD /d 65535 /f >nul 2>&1
echo Done.
echo.
echo [5/5] Resetting network adapter...
netsh winsock reset >nul 2>&1
netsh int ip reset >nul 2>&1
echo Done.
echo.
echo ========================================
echo Network optimizations applied!
echo ========================================
echo.
echo Restart required for network changes.
echo.
pause
