# Windows Temp Deep Clean
# Run from PowerShell as Admin

Write-Host "=== WINDOWS DEEP CLEAN ===" -ForegroundColor Green

# User Temp - delete everything older than 1 day
$temp = "$env:LOCALAPPDATA\Temp"
$before = (Get-ChildItem $temp -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Get-ChildItem $temp -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-1) } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
$after = (Get-ChildItem $temp -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Write-Host "User Temp freed: $([math]::Round(($before-$after)/1MB)) MB"

# System Temp
$sysTemp = "C:\Windows\Temp"
$before = (Get-ChildItem $sysTemp -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Get-ChildItem $sysTemp -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
$after = (Get-ChildItem $sysTemp -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Write-Host "System Temp freed: $([math]::Round(($before-$after)/1MB)) MB"

# Windows Update
Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
$before = (Get-ChildItem "C:\Windows\SoftwareDistribution\Download" -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Remove-Item "C:\Windows\SoftwareDistribution\Download\*" -Recurse -Force -ErrorAction SilentlyContinue
Start-Service wuauserv
Write-Host "WU Cache freed: $([math]::Round($before/1MB)) MB"

# Thumbnail cache
$thumbCache = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
$before = (Get-ChildItem "$thumbCache\thumbcache_*.db" -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Remove-Item "$thumbCache\thumbcache_*.db" -Force -ErrorAction SilentlyContinue
Write-Host "Thumbnail cache freed: $([math]::Round($before/1MB)) MB"

# Chrome (close Chrome first!)
$chromePaths = @(
    "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache",
    "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Code Cache",
    "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Service Worker\CacheStorage"
)
$totalFreed = 0
foreach ($p in $chromePaths) {
    if (Test-Path $p) {
        $before = (Get-ChildItem $p -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue
        $totalFreed += $before
    }
}
Write-Host "Chrome freed: $([math]::Round($totalFreed/1MB)) MB"

# Recycle Bin
(New-Object -ComObject Shell.Application).NameSpace(0xa).Items() | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Recycle Bin emptied"

# Run cleanmgr for system cleanup
Write-Host "`n--- Run Disk Cleanup ---" -ForegroundColor Cyan
Write-Host "cleanmgr /d C: /VERYLOWDISK" -ForegroundColor White

Write-Host "`n=== DONE ===" -ForegroundColor Green
