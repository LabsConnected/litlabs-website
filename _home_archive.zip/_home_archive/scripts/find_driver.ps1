# Try to find and download latest ELAN driver for Acer Nitro 5 AN515-54
# First check Acer support API

$model = "AN515-54"
$series = "Nitro 5"

# Try Acer's driver API
$headers = @{
    "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}

Write-Host "Searching for Acer Nitro 5 AN515-54 ELAN driver..."

# Try to get driver list from Acer support
try {
    $url = "https://www.acer.com/ac/US-en/content/support-product/$model"
    Write-Host "Support page: $url"
} catch {}

# Try direct ELAN driver search
try {
    $searchUrl = "https://www.acer.com/ac/US-en/content/support"
    Write-Host "Support home: $searchUrl"
} catch {}

Write-Host ""
Write-Host "Checking Windows Update for driver..."
$us = New-Object -ComObject Microsoft.Update.Session
$sr = $us.CreateUpdateSearcher()
$res = $sr.Search("IsInstalled=0 and Type='Driver'")
$touchpadDrivers = $res.Updates | Where-Object { $_.Title -match 'ELAN|Touchpad|Touch|Pointing|Synaptics|I2C' }
if ($touchpadDrivers) {
    Write-Host "Found $($touchpadDrivers.Count) touchpad driver update(s):"
    $touchpadDrivers | ForEach-Object {
        Write-Host "  - $($_.Title)"
    }
} else {
    Write-Host "No touchpad driver updates found via Windows Update."
}

Write-Host ""
Write-Host "All available driver updates:"
$res.Updates | ForEach-Object {
    Write-Host "  - $($_.Title)"
}
