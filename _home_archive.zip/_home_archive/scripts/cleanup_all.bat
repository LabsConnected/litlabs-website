@echo off
REM ============================================
REM Windows System Cleanup Script
REM Run as Administrator
REM ============================================

setlocal enabledelayedexpansion

title Windows Cleanup - Running as Administrator

REM Check for admin privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo.
    echo ❌ ERROR: This script requires Administrator privileges.
    echo Right-click this file and select "Run as administrator"
    echo.
    pause
    exit /b 1
)

cls
echo.
echo ════════════════════════════════════════════════════════════════
echo   LITLABS SYSTEM CLEANUP
echo   Cleaning temporary files, caches, and hibernation...
echo ════════════════════════════════════════════════════════════════
echo.

REM Initialize counters
set /a freed=0

REM ============================================
REM 1. WINDOWS TEMP CLEANUP
REM ============================================
echo [1/6] Cleaning Windows User Temp (%TEMP%)...
if exist "%TEMP%\" (
    for /f %%A in ('dir "%TEMP%" /s /b 2^>nul ^| find /c /v ""') do set before=%%A
    del /q /s "%TEMP%\*" >nul 2>&1
    for /f %%A in ('dir "%TEMP%" /s /b 2^>nul ^| find /c /v ""') do set after=%%A
    echo   ✓ Cleaned
) else (
    echo   ✓ No temp files
)

REM ============================================
REM 2. SYSTEM TEMP CLEANUP
REM ============================================
echo [2/6] Cleaning System Temp (C:\Windows\Temp)...
if exist "C:\Windows\Temp\" (
    del /q /s "C:\Windows\Temp\*" >nul 2>&1
    echo   ✓ Cleaned
) else (
    echo   ✓ No system temp
)

REM ============================================
REM 3. WINDOWS UPDATE CACHE
REM ============================================
echo [3/6] Cleaning Windows Update cache...
net stop wuauserv >nul 2>&1
if exist "C:\Windows\SoftwareDistribution\Download\" (
    del /q /s "C:\Windows\SoftwareDistribution\Download\*" >nul 2>&1
    echo   ✓ WU cache cleared
) else (
    echo   ✓ No WU cache
)
net start wuauserv >nul 2>&1

REM ============================================
REM 4. CRASH DUMPS
REM ============================================
echo [4/6] Cleaning crash dumps...
if exist "%LOCALAPPDATA%\CrashDumps\" (
    del /q "%LOCALAPPDATA%\CrashDumps\*" >nul 2>&1
    echo   ✓ Crash dumps cleared
) else (
    echo   ✓ No crash dumps
)

REM ============================================
REM 5. RECYCLE BIN
REM ============================================
echo [5/6] Emptying Recycle Bin...
RD /S /Q "%systemdrive%\$Recycle.bin" >nul 2>&1
echo   ✓ Recycle bin emptied

REM ============================================
REM 6. DISABLE HIBERNATION
REM ============================================
echo [6/6] Disabling Hibernation (frees 5-15GB)...
powercfg /hibernate off >nul 2>&1
echo   ✓ Hibernation disabled

echo.
echo ════════════════════════════════════════════════════════════════
echo   ✅ CLEANUP COMPLETE
echo ════════════════════════════════════════════════════════════════
echo.
echo Your system should now have more available disk space.
echo.
echo Next steps for LiTLabs deployment:
echo   1. Deploy Supabase schema (PRODUCTION_LAUNCH.md)
echo   2. Add env vars to Vercel
echo   3. Test locally
echo   4. Redeploy to production
echo.
pause
