schtasks /create /tn "FixInputDev" /tr "powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File C:/Users/litbi/fix_all_v2.ps1" /sc once /st 00:00 /ru SYSTEM /rl HIGHEST /f
schtasks /run /tn "FixInputDev"
echo Task started. Waiting...
timeout /t 20 /nobreak >nul
schtasks /query /tn "FixInputDev" /v /fo LIST
schtasks /delete /tn "FixInputDev" /f
echo Done.
