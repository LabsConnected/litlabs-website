# LiTTree Lab Studios - PC Cleanup & Speed Tune
# Run this in PowerShell AS ADMINISTRATOR
# Safe targets only: known stale files, temp cleanup, project root clutter

$ErrorActionPreference = 'SilentlyContinue'

Write-Host "=== LiTTree Cleanup ===" -ForegroundColor Cyan

# 1. Project Root Cleanup (LiTTreeLabstudios)
$projectRoot = "C:\home\litbit\LiTTreeLabstudios"
if (Test-Path $projectRoot) {
    Write-Host "Cleaning project root: $projectRoot" -ForegroundColor Yellow

    $stale = @(
        "$projectRoot\.netlify",
        "$projectRoot\tsconfig.tsbuildinfo",
        "$projectRoot\AGENTS.md",
        "$projectRoot\CLAUDE.md",
        "$projectRoot\GEMINI.md",
        "$projectRoot\SOUL.md",
        "$projectRoot\IDENTITY.md",
        "$projectRoot\HEARTBEAT.md",
        "$projectRoot\MANIFEST.md",
        "$projectRoot\USER.md",
        "$projectRoot\TOOLS.md",
        "$projectRoot\QUICKREF.md"
    )

    foreach ($path in $stale) {
        if (Test-Path $path) {
            Remove-Item -Recurse -Force $path
            Write-Host "  - Removed: $path"
        }
    }

    # Remove build logs and deploy artifacts in project root
    Get-ChildItem $projectRoot -File | Where-Object { $_.Extension -match '\.(log|txt|json|md)$' -and $_.Name -match 'build|deploy|output' } | ForEach-Object {
        Remove-Item $_.FullName -Force
        Write-Host "  - Removed build artifact: $($_.FullName)"
    }
}

# 2. Empty nested duplicate project path if empty
$emptyNested = Join-Path $projectRoot "home\litbit\LiTTreeLabstudios"
if (Test-Path $emptyNested) {
    $items = Get-ChildItem $emptyNested -Force
    if ($items.Count -eq 0) {
        Remove-Item -Recurse -Force $emptyNested
        Write-Host "  - Removed empty nested duplicate path" -ForegroundColor Green
    }
}

# 3. Temp folder cleanup (safe targets)
$tempPaths = @(
    "$env:LOCALAPPDATA\Temp\wsl-crashes",
    "$env:LOCALAPPDATA\Temp\DiagOutputDir",
    "$env:LOCALAPPDATA\Temp\DockerDesktop",
    "$env:LOCALAPPDATA\Temp\WinGet",
    "$env:LOCALAPPDATA\Temp\*.vhdx",
    "$env:LOCALAPPDATA\Temp\windsurf-*",
    "$env:LOCALAPPDATA\Temp\*-updater*.exe"
)

foreach ($path in $tempPaths) {
    $expanded = Expand-EnvironmentVariables $path
    $items = Get-Item $expanded -Force -ErrorAction SilentlyContinue
    if ($items) {
        Remove-Item -Recurse -Force $items
        Write-Host "  - Cleaned temp: $expanded"
    }
}

# 4. Docker cleanup (images/containers if not actively using)
$dockerRunning = Get-Process "docker" -ErrorAction SilentlyContinue
if (-not $dockerRunning) {
    Write-Host "Docker not running, cleaning leftover Docker data..." -ForegroundColor Yellow
    $dockerData = "$env:LOCALAPPDATA\Docker"
    if (Test-Path $dockerData) {
        Remove-Item -Recurse -Force $dockerData
        Write-Host "  - Removed Docker local data"
    }
}

# 5. Devin/AI agent leftovers (safe if not actively using)
$devinPath = "$env:LOCALAPPDATA\Devin"
if (Test-Path $devinPath) {
    Remove-Item -Recurse -Force $devinPath
    Write-Host "  - Removed Devin cache/data"
}

Write-Host "=== Cleanup Complete ===" -ForegroundColor Cyan

# 6. System optimization
Write-Host "=== Running System Optimizations ===" -ForegroundColor Cyan

# Enable TRIM for SSD
$trimStatus = (fsutil behavior query disabledeletenotify 2>$null)
if ($trimStatus -match '1') {
    fsutil behavior set disabledeletenotify 0
    Write-Host "  - Enabled SSD TRIM" -ForegroundColor Green
} else {
    Write-Host "  - SSD TRIM already enabled"
}

# Disk Cleanup
Start-Process cleanmgr -ArgumentList "/sageset:65535","/sagerun:65535" -Wait -ErrorAction SilentlyContinue
Write-Host "  - Launched disk cleanup (check UI if it appeared)" -ForegroundColor Yellow

Write-Host ""
Write-Host "=== Performance Report ===" -ForegroundColor Cyan
$os = Get-CimInstance Win32_OperatingSystem
$diskC = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$diskE = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='E:'"

Write-Host "RAM: $([math]::Round($os.TotalVisibleMemorySize/1MB, 1)) GB total | Free: $([math]::Round($os.FreePhysicalMemory/1MB, 1)) GB"
Write-Host "C:  $([math]::Round($diskC.Size/1GB, 1)) GB total | Free: $([math]::Round($diskC.FreeSpace/1GB, 1)) GB"
Write-Host "E:  $([math]::Round($diskE.Size/1GB, 1)) GB total | Free: $([math]::Round($diskE.FreeSpace/1GB, 1)) GB"

# Show top RAM processes
Write-Host ""
Write-Host "Top RAM Processes:" -ForegroundColor Cyan
Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 Name, @{N='RAM_MB';E={[math]::Round($_.WorkingSet64/1MB)}} | Format-Table -AutoSize

# Return exit code
exit 0
