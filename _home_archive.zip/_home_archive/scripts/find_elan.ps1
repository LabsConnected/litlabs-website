# List all OEM drivers related to ELAN
$pnputil = & pnputil /enum-drivers 2>&1
$elanSections = $pnputil | Select-String -Pattern "ELAN" -Context 0,5
$elanSections | ForEach-Object { Write-Host $_.Line; $_.Context.PostContext | ForEach-Object { Write-Host "  $_" } }

Write-Host "`n---"
# Try to find the specific driver package
$driverPackages = Get-ChildItem "C:\Windows\System32\DriverStore\FileRepository" | Where-Object { $_.Name -match "elan" -or $_.Name -match "oem29" }
$driverPackages | ForEach-Object {
    Write-Host "Package: $($_.Name)"
    $infFiles = Get-ChildItem $_.FullName -Filter "*.inf" -ErrorAction SilentlyContinue
    $infFiles | ForEach-Object { Write-Host "  INF: $($_.Name)" }
}

Write-Host "`n---"
# Check if there's a newer driver in the driver store
$allInf = Get-ChildItem "C:\Windows\System32\DriverStore\FileRepository" -Filter "*.inf" -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "elan" -or $_.Name -match "touch" }
$allInf | ForEach-Object { Write-Host $_.FullName }
