# Check ELAN driver details
$elan = Get-CimInstance -ClassName Win32_PnPSignedDriver | Where-Object { $_.DeviceName -match 'ELAN' }
if ($elan) {
    $elan | ForEach-Object {
        Write-Host "=== ELAN Driver ==="
        Write-Host "Name: $($_.DeviceName)"
        Write-Host "Version: $($_.DriverVersion)"
        Write-Host "Date: $($_.DriverDate)"
        Write-Host "Manufacturer: $($_.Manufacturer)"
        Write-Host "INF: $($_.InfName)"
        Write-Host "IsSigned: $($_.IsSigned)"
        Write-Host "SignerName: $($_.SignerName)"
    }
}

Write-Host ""

# Check for problem devices
$problems = Get-PnpDevice -Status Error,Degraded
if ($problems) {
    Write-Host "=== Problem Devices ==="
    $problems | ForEach-Object {
        Write-Host "$($_.Status) $($_.Class) $($_.FriendlyName) - $($_.Problem)"
    }
} else {
    Write-Host "No problem devices found"
}

Write-Host ""

# Check USB selective suspend
$usbSuspend = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\USB' -Name 'DisableSelectiveSuspend' -ErrorAction SilentlyContinue
Write-Host "USB Selective Suspend disabled: $($usbSuspend.DisableSelectiveSuspend)"

# Check power plan for USB settings
$powerPlan = (powercfg /getactivescheme).Split()[3]
Write-Host "Active power plan GUID: $powerPlan"

# Check for mouse-specific power management
Write-Host ""
Write-Host "=== Mouse Power Management ==="
$mouseDevices = Get-PnpDevice -Class Mouse -Status OK
$mouseDevices | ForEach-Object {
    Write-Host "Device: $($_.FriendlyName)"
    $powerMgmt = Get-CimInstance -ClassName Win32_PowerManagementEvent -ErrorAction SilentlyContinue
}
