# Try to download ELAN driver from Acer support
# Acer Nitro 5 AN515-54 uses ELAN I2C touchpad

$headers = @{
    "User-Agent" = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

# Try Acer's API for driver downloads
$modelId = "AN515-54"

# Acer support URLs to try
$urls = @(
    "https://www.acer.com/ac/US-en/content/support-product/$modelId",
    "https://global-download.acer.com/OSDriver/ELAN/ELAN_I2C/13.6.14.1/ELAN_I2C.zip",
    "https://global-download.acer.com/OSDriver/ELAN/ELAN_I2C/"
)

# Try to scrape the Acer support page for ELAN driver
Write-Host "Trying to find ELAN driver from Acer support..."

try {
    $response = Invoke-WebRequest -Uri "https://www.acer.com/ac/US-en/content/support-product/$modelId" -Headers $headers -UseBasicParsing -TimeoutSec 15
    $content = $response.Content
    
    # Look for ELAN driver links
    $matches2 = [regex]::Matches($content, 'href="([^"]*ELAN[^"]*)"')
    if ($matches2.Count -gt 0) {
        Write-Host "Found ELAN links:"
        $matches2 | ForEach-Object { Write-Host "  $($_.Groups[1].Value)" }
    }
    
    # Look for any driver download links
    $dlMatches = [regex]::Matches($content, 'href="([^"]*download[^"]*)"')
    if ($dlMatches.Count -gt 0) {
        Write-Host "Found download links:"
        $dlMatches | ForEach-Object { Write-Host "  $($_.Groups[1].Value)" }
    }
    
    # Look for touchpad driver
    $tpMatches = [regex]::Matches($content, 'touchpad|ELAN|Synaptics', [regex]::Options::IgnoreCase)
    Write-Host "Found $($tpMatches.Count) touchpad-related references"
    
} catch {
    Write-Host "Could not reach Acer support: $($_.Exception.Message)"
}

# Try alternative: search for Acer Nitro 5 AN515-54 drivers on the Acer download server
Write-Host ""
Write-Host "Trying Acer download server..."
try {
    $dlResponse = Invoke-WebRequest -Uri "https://global-download.acer.com/OSDriver/" -Headers $headers -UseBasicParsing -TimeoutSec 10
    Write-Host "Acer download server is accessible"
} catch {
    Write-Host "Acer download server: $($_.Exception.Message)"
}

Write-Host ""
Write-Host "=== Manual download instructions ==="
Write-Host "Go to: https://www.acer.com/ac/US-en/content/support-product/AN515-54"
Write-Host "Select: Touchpad Driver (ELAN I2C)"
Write-Host "Current version: 13.6.14.1 (yours) - look for newer"
