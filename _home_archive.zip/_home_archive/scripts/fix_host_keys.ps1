﻿# Generate host keys if missing
& "C:\Windows\System32\OpenSSH\ssh-keygen.exe" -A

$keyFiles = @(
    "C:\ProgramData\ssh\ssh_host_rsa_key",
    "C:\ProgramData\ssh\ssh_host_ecdsa_key",
    "C:\ProgramData\ssh\ssh_host_ed25519_key"
)

foreach ($key in $keyFiles) {
    if (Test-Path $key) {
        # Set owner to SYSTEM (Windows default for host keys)
        takeown /F $key /A
        icacls $key /setowner "NT SERVICE\SSHD"
        
        # Reset ACLs: Only SSHD, SYSTEM, and Administrators
        $acl = Get-Acl $key
        $acl.SetAccessRuleProtection($true, $false)
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("NT SERVICE\SSHD", "Read", "Allow")))
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM", "FullControl", "Allow")))
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("BUILTIN\Administrators", "FullControl", "Allow")))
        Set-Acl $key $acl
        Write-Host "Fixed $key"
    }
}

Restart-Service sshd
