# Create and run a scheduled task as SYSTEM to apply all fixes without UAC
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument '-ExecutionPolicy Bypass -WindowStyle Hidden -File C:/Users/litbi/fix_all_v2.ps1'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$task = New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal
Register-ScheduledTask -TaskName "FixInputDevices" -InputObject $task -Force | Out-Null
Start-ScheduledTask -TaskName "FixInputDevices"
Write-Host "Task created and started. Waiting for result..."
Start-Sleep -Seconds 15
$info = Get-ScheduledTask -TaskName "FixInputDevices"
Write-Host "State: $($info.State)"
$history = Get-ScheduledTaskInfo -TaskName "FixInputDevices" -ErrorAction SilentlyContinue
if ($history) {
    Write-Host "Last Result: $($history.LastTaskResult)"
    Write-Host "Last Run: $($history.LastRunTime)"
    Write-Host "Next Run: $($history.NextRunTime)"
}
# Cleanup
Unregister-ScheduledTask -TaskName "FixInputDevices" -Confirm:$false -ErrorAction SilentlyContinue
Write-Host "Task cleaned up."
