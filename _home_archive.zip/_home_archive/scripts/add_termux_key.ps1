#Requires -RunAsAdministrator
$key = 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILQDMyq7pmxgD6dY1vAYc7XYiHpNHQ2BfKvrxF8wTuOq termux@phone'
$file = 'C:\ProgramData\ssh\administrators_authorized_keys'
if (-not (Test-Path $file)) {
    New-Item -ItemType File -Path $file -Force | Out-Null
}
takeown /F $file /A | Out-Null
icacls $file /inheritance:r | Out-Null
icacls $file /grant "$env:USERDOMAIN\$env:USERNAME`:F" | Out-Null
if (-not (Select-String -Path $file -Pattern [regex]::Escape($key) -Quiet)) {
    Add-Content $file $key
}
icacls $file /setowner 'NT SERVICE\SSHD' | Out-Null
icacls $file /remove "$env:USERDOMAIN\$env:USERNAME" | Out-Null
icacls $file /grant:r 'NT SERVICE\SSHD:F' | Out-Null
Write-Host 'Termux key added to administrators_authorized_keys.' -ForegroundColor Green
