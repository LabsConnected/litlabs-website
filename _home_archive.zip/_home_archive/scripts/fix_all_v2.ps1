# Check if running as admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if (-not $isAdmin) {
    Write-Host "NOT running as admin. Attempting to elevate..."
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File C:/Users/litbi/fix_all_input.ps1"
    exit
}

Write-Host "Running as admin. Applying fixes..."

# 1. Disable USB selective suspend
Write-Host "`n[1/7] Disabling USB selective suspend..."
powercfg /setacvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0 2>$null
powercfg /setdcvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0 2>$null
powercfg /setactive scheme_current 2>$null
Write-Host "  Done."

# 2. Power management on mouse
Write-Host "`n[2/7] Disabling power management on mouse devices..."
Get-PnpDevice -Class Mouse -Status OK -ErrorAction SilentlyContinue | ForEach-Object {
    $p = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters"
    Set-ItemProperty -Path $p -Name "EnhancedPowerManagementEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $p -Name "SelectiveSuspendEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $p -Name "AllowIdleIrpInD3" -Value 0 -ErrorAction SilentlyContinue
    Write-Host "  Done: $($_.FriendlyName)"
}

# 3. Power management on keyboard
Write-Host "`n[3/7] Disabling power management on keyboard devices..."
Get-PnpDevice -Class Keyboard -Status OK -ErrorAction SilentlyContinue | ForEach-Object {
    $p = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters"
    Set-ItemProperty -Path $p -Name "EnhancedPowerManagementEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $p -Name "SelectiveSuspendEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $p -Name "AllowIdleIrpInD3" -Value 0 -ErrorAction SilentlyContinue
    Write-Host "  Done: $($_.FriendlyName)"
}

# 4. Mouse settings
Write-Host "`n[4/7] Fixing mouse settings..."
$XC = [byte[]](0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC0,0xCC,0x0C,0x00,0x00,0x00,0x00,0x00,0x80,0x99,0x19,0x00,0x00,0x00,0x00,0x00,0x40,0x66,0x26,0x00,0x00,0x00,0x00,0x00,0x00,0x33,0x33,0x00,0x00,0x00,0x00,0x00)
$YC = [byte[]](0x00,0x00,0x38,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x70,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xA8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE4,0xBE,0x92,0x00,0x00,0x00)
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseXCurve' -Value $XC -Type Binary -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseYCurve' -Value $YC -Type Binary -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSpeed' -Value '1' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold1' -Value '6' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold2' -Value '10' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSensitivity' -Value '10' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseTrails' -Value '0' -Type String
Write-Host "  Done."

# 5. Keyboard settings
Write-Host "`n[5/7] Setting keyboard to fastest..."
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardDelay' -Value '0' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardSpeed' -Value '31' -Type String
Write-Host "  Done."

# 6. Desktop responsiveness
Write-Host "`n[6/7] Optimizing desktop responsiveness..."
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '0' -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseHoverTime' -Value '0' -Type String -ErrorAction SilentlyContinue
Write-Host "  Done."

# 7. Windows Update check for ELAN driver
Write-Host "`n[7/7] Checking for ELAN driver update..."
try {
    $us = New-Object -ComObject Microsoft.Update.Session
    $sr = $us.CreateUpdateSearcher()
    $res = $sr.Search("IsInstalled=0 and Type='Driver'")
    $elanUpdates = $res.Updates | Where-Object { $_.Title -match 'ELAN|Touchpad|Synaptics|Pointing' }
    if ($elanUpdates) {
        Write-Host "  Found updates:"
        $elanUpdates | ForEach-Object { Write-Host "    - $($_.Title)" }
        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
        $elanUpdates | ForEach-Object { $coll.Add($_) | Out-Null }
        $dl = $us.CreateUpdateDownloader()
        $dl.Updates = $coll
        $dl.Download() | Out-Null
        $inst = $us.CreateUpdateInstaller()
        $inst.Updates = $coll
        $r = $inst.Install()
        Write-Host "  Install result: $($r.ResultCode)"
    } else {
        Write-Host "  No ELAN driver update found. Current: v13.6.14.1 (2019)"
        Write-Host "  Go to your laptop manufacturer's site to download the latest."
    }
} catch {
    Write-Host "  Could not check: $_"
}

Write-Host "`n=== ALL DONE ==="
Write-Host "Restart Windows for changes to take effect."
