# Windows cleanup script - Save as C:\Users\litbi\win_clean.ps1 and run from PowerShell as Admin
# Or run each section individually

Write-Host "=== WINDOWS CLEANUP ===" -ForegroundColor Green

# 1. User Temp (7.4GB found)
Write-Host "`n1. Cleaning User Temp..." -ForegroundColor Yellow
$tempPath = "$env:LOCALAPPDATA\Temp"
$before = (Get-ChildItem $tempPath -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Remove-Item "$tempPath\*" -Recurse -Force -ErrorAction SilentlyContinue
$after = (Get-ChildItem $tempPath -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Write-Host "   Freed: $([math]::Round(($before - $after)/1MB)) MB"

# 2. System Temp
Write-Host "2. Cleaning System Temp..." -ForegroundColor Yellow
$sysTemp = "C:\Windows\Temp"
$before = (Get-ChildItem $sysTemp -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Remove-Item "$sysTemp\*" -Recurse -Force -ErrorAction SilentlyContinue
$after = (Get-ChildItem $sysTemp -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Write-Host "   Freed: $([math]::Round(($before - $after)/1MB)) MB"

# 3. Windows Update Cache
Write-Host "3. Cleaning Windows Update cache..." -ForegroundColor Yellow
Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
$wuBefore = (Get-ChildItem "C:\Windows\SoftwareDistribution\Download" -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Remove-Item "C:\Windows\SoftwareDistribution\Download\*" -Recurse -Force -ErrorAction SilentlyContinue
Start-Service wuauserv -ErrorAction SilentlyContinue
Write-Host "   Freed: $([math]::Round($wuBefore/1MB)) MB"

# 4. Crash Dumps
Write-Host "4. Cleaning Crash Dumps..." -ForegroundColor Yellow
$crashPath = "$env:LOCALAPPDATA\CrashDumps"
$before = (Get-ChildItem $crashPath -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Remove-Item "$crashPath\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "   Freed: $([math]::Round($before/1MB)) MB"

# 5. Chrome Cache (safe - Chrome rebuilds it)
Write-Host "5. Cleaning Chrome Cache..." -ForegroundColor Yellow
$chromeCache = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache"
$chromeCode = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Code Cache"
$before1 = (Get-ChildItem $chromeCache -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
$before2 = (Get-ChildItem $chromeCode -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Remove-Item "$chromeCache\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$chromeCode\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "   Freed: $([math]::Round(($before1 + $before2)/1MB)) MB"

# 6. Discord Cache
Write-Host "6. Cleaning Discord Cache..." -ForegroundColor Yellow
$dcCache = "$env:LOCALAPPDATA\Discord\Cache"
if (Test-Path $dcCache) {
    $before = (Get-ChildItem $dcCache -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    Remove-Item "$dcCache\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "   Freed: $([math]::Round($before/1MB)) MB"
}

# 7. npm-cache on Windows
Write-Host "7. Cleaning npm-cache..." -ForegroundColor Yellow
$npmCache = "$env:LOCALAPPDATA\npm-cache"
if (Test-Path $npmCache) {
    $before = (Get-ChildItem $npmCache -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    Remove-Item "$npmCache\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "   Freed: $([math]::Round($before/1MB)) MB"
}

# 8. NuGet cache
Write-Host "8. Cleaning NuGet cache..." -ForegroundColor Yellow
$nuCache = "$env:LOCALAPPDATA\NuGet\Cache"
if (Test-Path $nuCache) {
    $before = (Get-ChildItem $nuCache -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    Remove-Item "$nuCache\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "   Freed: $([math]::Round($before/1MB)) MB"
}

# 9. Run Disk Cleanup (cleanmgr) for system files
Write-Host "`n9. Running Disk Cleanup (system)..." -ForegroundColor Yellow
Write-Host "   Run manually: cleanmgr /d C: /VERYLOWDISK" -ForegroundColor Cyan
Write-Host "   Or Settings > System > Storage > Temporary Files" -ForegroundColor Cyan

Write-Host "`n=== DONE ===" -ForegroundColor Green
