Set shell = CreateObject("Shell.Application")
shell.ShellExecute "reg.exe", "import C:\Users\litbi\input_fixes_hklm.reg", "", "runas", 1
