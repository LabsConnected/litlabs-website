#!/bin/bash
# Run once on WSL to install the mobile dev script
# Execute: bash /mnt/c/Users/litbi/mobile_setup.sh

export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && source "$NVM_DIR/nvm.sh"
export PATH="$HOME/bin:$HOME/.local/bin:$PATH"

PROJ="$HOME/LiTTreeLabstudios"
BIN="$PROJ/bin"

# ── Write mobile.sh ──────────────────────────────────────────
cat > "$BIN/mobile.sh" << 'EOF'
#!/bin/bash
# ============================================================
# MOBILE DEV LOOP — ssh litbit@monolith 'bash ~/LiTTreeLabstudios/bin/mobile.sh'
# ============================================================
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && source "$NVM_DIR/nvm.sh"
export PATH="$HOME/bin:$HOME/.local/bin:$PATH"

PROJ="$HOME/LiTTreeLabstudios"
CF_PID="/tmp/cloudflared.pid"
LOG="$PROJ/dev.log"

echo ""
echo "╔══════════════════════════════════╗"
echo "║   LiTTree Dev Loop — Mobile      ║"
echo "╚══════════════════════════════════╝"
echo ""

# 1. Sync latest code from origin
echo "[1/4] Syncing code..."
cd "$PROJ"
WIP=false
if ! git diff --quiet || ! git diff --cached --quiet; then
  git stash push -m "mobile-wip-$(date +%s)" 2>/dev/null
  WIP=true
fi
git pull --rebase origin main 2>&1 | tail -3
if [ "$WIP" = true ]; then git stash pop 2>/dev/null || true; fi
if git diff --name-only ORIG_HEAD HEAD 2>/dev/null | grep -q 'package.json'; then
  echo "  Installing new deps..."
  npm install --silent
fi
echo "  OK: code is current"

# 2. Kill any existing dev server
echo ""
echo "[2/4] Clearing old processes..."
pkill -f 'next dev' 2>/dev/null || true
sleep 1

# 3. Start/restart Cloudflare tunnel in background
echo ""
echo "[3/4] Starting Cloudflare tunnel..."
if [ -f "$CF_PID" ] && kill -0 "$(cat $CF_PID)" 2>/dev/null; then
  echo "  Tunnel already running (PID $(cat $CF_PID))"
else
  nohup "$HOME/bin/cloudflared" tunnel --config ~/.cloudflared/config.yml run >> /tmp/cloudflared.log 2>&1 &
  echo $! > "$CF_PID"
  echo "  Tunnel started (PID $(cat $CF_PID))"
fi
echo "  jarvis.litlabs.net  →  http://127.0.0.1:3000"
echo "  api.litlabs.net     →  http://127.0.0.1:3000"

# 4. Start dev server (foreground)
echo ""
echo "[4/4] Starting Next.js dev server..."
echo "  Logs: $LOG"
echo "  URL:  https://jarvis.litlabs.net"
echo ""
cd "$PROJ"
npm run dev 2>&1 | tee -a "$LOG"
EOF

chmod +x "$BIN/mobile.sh"
echo "✅ mobile.sh installed at $BIN/mobile.sh"

# ── Write a quick DNS check script ───────────────────────────
cat > "$BIN/dns-check.sh" << 'EOF'
#!/bin/bash
echo "=== Tunnel status ==="
CF_PID="/tmp/cloudflared.pid"
if [ -f "$CF_PID" ] && kill -0 "$(cat $CF_PID)" 2>/dev/null; then
  echo "cloudflared: RUNNING (PID $(cat $CF_PID))"
else
  echo "cloudflared: STOPPED"
fi
echo ""
echo "=== DNS resolution ==="
host jarvis.litlabs.net 2>&1 | head -3
host api.litlabs.net 2>&1 | head -3
echo ""
echo "=== Port 3000 ==="
ss -tlnp | grep :3000 || echo "Nothing on :3000"
EOF

chmod +x "$BIN/dns-check.sh"
echo "✅ dns-check.sh installed at $BIN/dns-check.sh"

# ── Add jarvis CNAME via cloudflared route dns ────────────────
echo ""
echo "[DNS] Adding jarvis.litlabs.net CNAME to tunnel..."
"$HOME/bin/cloudflared" tunnel route dns 8a995361-6c8b-42d8-93d0-5f04d1214c0b jarvis.litlabs.net 2>&1 || echo "  (May already exist or need CF login)"

echo ""
echo "✅ Setup complete!"
echo ""
echo "From your phone (Termux):"
echo "  ssh litbit@100.107.123.73 'bash ~/LiTTreeLabstudios/bin/mobile.sh'"
echo ""
echo "Or with tmux for persistence:"
echo "  ssh litbit@100.107.123.73 'tmux new-session -d -s dev \"bash ~/LiTTreeLabstudios/bin/mobile.sh\"'"
echo ""
