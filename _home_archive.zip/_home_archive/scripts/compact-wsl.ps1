# Compact the WSL ext4.vhdx to reclaim unused space on C drive.
# Run as Administrator: right-click this file -> Run with PowerShell (as Admin).
#
# Current size: 115G on disk, ~50G used inside WSL.
# Expected after: ~50-55G on disk. Reclaims ~60G.

$ErrorActionPreference = 'Stop'

$Vhdx = "$env:LOCALAPPDATA\wsl\{c0e55d37-205e-4c88-b54f-c18a1cd86dc9}\ext4.vhdx"

if (-not (Test-Path $Vhdx)) {
    Write-Host "VHDX not found at: $Vhdx" -ForegroundColor Red
    Write-Host "Search known locations..."
    $found = Get-ChildItem -Path "$env:LOCALAPPDATA\wsl" -Recurse -Filter 'ext4.vhdx' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $Vhdx = $found.FullName } else { exit 1 }
}

Write-Host "Target VHDX: $Vhdx"
$before = (Get-Item $Vhdx).Length / 1GB
Write-Host ("Current size: {0:N2} GB" -f $before)

Write-Host "`nStep 1/4: Shutting down WSL..." -ForegroundColor Cyan
wsl --shutdown
Start-Sleep -Seconds 3

Write-Host "Step 2/4: Starting WSL to trim unused blocks..." -ForegroundColor Cyan
wsl -u root -e bash -c "
    echo 'Running fstrim...'
    /usr/sbin/fstrim -v /
    echo 'Trim complete.'
" 2>&1 | ForEach-Object { Write-Host $_ }

Write-Host "Step 3/4: Shutting down WSL again..." -ForegroundColor Cyan
wsl --shutdown
Start-Sleep -Seconds 3

Write-Host "Step 4/4: Compacting VHDX via diskpart..." -ForegroundColor Cyan
$diskpartScript = @"
select vdisk file="$Vhdx"
attach vdisk readonly
compact vdisk
detach vdisk
exit
"@
$tempScript = Join-Path $env:TEMP "compact-wsl-diskpart.txt"
$diskpartScript | Set-Content -Path $tempScript -Encoding ASCII
diskpart /s $tempScript
Remove-Item $tempScript -Force

Write-Host "Step 5/5: Enabling auto-compaction (sparse VHDX)..." -ForegroundColor Cyan
# WSL 2.7+ supports sparse vhdx - shrink happens automatically going forward.
# This requires the --allow-unsafe flag on newer Windows builds.
try {
    $distro = (wsl -l -v | Where-Object { $_ -match '^\*' } | ForEach-Object { ($_ -split '\s+')[1] }) -join ''
    if (-not $distro) { $distro = "Ubuntu" }
    $sparse = wsl --manage $distro --set-sparse true --allow-unsafe 2>&1
    if ($sparse -match "Sparse VHD support is currently disabled") {
        Write-Host "Sparse mode not available on this build (non-fatal)." -ForegroundColor Yellow
    } else {
        Write-Host "Sparse mode enabled." -ForegroundColor Green
    }
} catch {
    Write-Host "Sparse mode could not be enabled (non-fatal)." -ForegroundColor Yellow
}

$after = (Get-Item $Vhdx).Length / 1GB
Write-Host ""
Write-Host ("Before: {0:N2} GB" -f $before)
Write-Host ("After:  {0:N2} GB" -f $after)
Write-Host ("Reclaimed: {0:N2} GB" -f ($before - $after)) -ForegroundColor Green
Write-Host ""
Write-Host "Done. Reopen WSL when ready."