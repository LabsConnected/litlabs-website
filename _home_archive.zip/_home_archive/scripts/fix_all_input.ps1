# === INPUT DEVICE FIX SCRIPT ===
# Run as Administrator

Write-Host "=== Fixing mouse and keyboard input ===" -ForegroundColor Cyan

# 1. Disable USB selective suspend (AC and DC)
Write-Host "`n[1/7] Disabling USB selective suspend..." -ForegroundColor Yellow
powercfg /setacvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0 2>$null
powercfg /setdcvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0 2>$null
powercfg /setacvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 2a737441-1930-4402-8d77-b2bebba308a3 0 2>$null
powercfg /setdcvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 2a737441-1930-4402-8d77-b2bebba308a3 0 2>$null
powercfg /setactive scheme_current 2>$null
Write-Host "  Done." -ForegroundColor Green

# 2. Disable power management on all mouse devices
Write-Host "`n[2/7] Disabling power management on mouse devices..." -ForegroundColor Yellow
$mouseDevices = Get-PnpDevice -Class Mouse -Status OK -ErrorAction SilentlyContinue
foreach ($dev in $mouseDevices) {
    $regPath = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($dev.InstanceId)\Device Parameters"
    Set-ItemProperty -Path $regPath -Name "EnhancedPowerManagementEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $regPath -Name "SelectiveSuspendEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $regPath -Name "AllowIdleIrpInD3" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $regPath -Name "D3ColdSupported" -Value 0 -ErrorAction SilentlyContinue
    Write-Host "  Disabled for: $($dev.FriendlyName)" -ForegroundColor Gray
}
Write-Host "  Done." -ForegroundColor Green

# 3. Disable power management on all keyboard devices
Write-Host "`n[3/7] Disabling power management on keyboard devices..." -ForegroundColor Yellow
$kbDevices = Get-PnpDevice -Class Keyboard -Status OK -ErrorAction SilentlyContinue
foreach ($dev in $kbDevices) {
    $regPath = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($dev.InstanceId)\Device Parameters"
    Set-ItemProperty -Path $regPath -Name "EnhancedPowerManagementEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $regPath -Name "SelectiveSuspendEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $regPath -Name "AllowIdleIrpInD3" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $regPath -Name "D3ColdSupported" -Value 0 -ErrorAction SilentlyContinue
    Write-Host "  Disabled for: $($dev.FriendlyName)" -ForegroundColor Gray
}
Write-Host "  Done." -ForegroundColor Green

# 4. Fix mouse acceleration curves and settings
Write-Host "`n[4/7] Fixing mouse acceleration settings..." -ForegroundColor Yellow
$XCurve = [byte[]](0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC0,0xCC,0x0C,0x00,0x00,0x00,0x00,0x00,0x80,0x99,0x19,0x00,0x00,0x00,0x00,0x00,0x40,0x66,0x26,0x00,0x00,0x00,0x00,0x00,0x00,0x33,0x33,0x00,0x00,0x00,0x00,0x00)
$YCurve = [byte[]](0x00,0x00,0x38,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x70,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xA8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE4,0xBE,0x92,0x00,0x00,0x00)
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseXCurve' -Value $XCurve -Type Binary -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseYCurve' -Value $YCurve -Type Binary -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSpeed' -Value '1' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold1' -Value '6' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold2' -Value '10' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSensitivity' -Value '10' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseTrails' -Value '0' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'ActiveWindowTracking' -Value 0 -Type DWord
Write-Host "  Done." -ForegroundColor Green

# 5. Set keyboard response speed to max
Write-Host "`n[5/7] Setting keyboard response to fastest..." -ForegroundColor Yellow
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardDelay' -Value '0' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardSpeed' -Value '31' -Type String
Write-Host "  Done." -ForegroundColor Green

# 6. Try to update ELAN driver via Windows Update
Write-Host "`n[6/7] Checking Windows Update for ELAN driver..." -ForegroundColor Yellow
try {
    $UpdateSession = New-Object -ComObject Microsoft.Update.Session
    $UpdateSearcher = $UpdateSession.CreateUpdateSearcher()
    $SearchResult = $UpdateSearcher.Search("IsInstalled=0 and Type='Driver' and Title contains 'ELAN'")
    if ($SearchResult.Updates.Count -gt 0) {
        Write-Host "  Found $($SearchResult.Updates.Count) ELAN driver update(s)!" -ForegroundColor Green
        $SearchResult.Updates | ForEach-Object { Write-Host "    - $($_.Title)" -ForegroundColor Gray }
        $UpdatesToDownload = New-Object -ComObject Microsoft.Update.UpdateColl
        $SearchResult.Updates | ForEach-Object { $UpdatesToDownload.Add($_) | Out-Null }
        $Downloader = $UpdateSession.CreateUpdateDownloader()
        $Downloader.Updates = $UpdatesToDownload
        $Downloader.Download() | Out-Null
        $UpdatesToInstall = New-Object -ComObject Microsoft.Update.UpdateColl
        $SearchResult.Updates | ForEach-Object { $UpdatesToInstall.Add($_) | Out-Null }
        $Installer = $UpdateSession.CreateUpdateInstaller()
        $Installer.Updates = $UpdatesToInstall
        $InstallResult = $Installer.Install()
        Write-Host "  Install result: $($InstallResult.ResultCode)" -ForegroundColor Green
    } else {
        Write-Host "  No ELAN driver updates available via Windows Update." -ForegroundColor Gray
        Write-Host "  You may need to download from your laptop manufacturer's website." -ForegroundColor Gray
    }
} catch {
    Write-Host "  Could not check Windows Update: $_" -ForegroundColor Red
}

# 7. Disable pointer precision enhancement smoothing (reduce input lag)
Write-Host "`n[7/7] Optimizing for low input lag..." -ForegroundColor Yellow
# Disable cursor shadow
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'CursorShadow' -Value 0 -Type DWord -ErrorAction SilentlyContinue
# Disable menu show delay
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '0' -Type String -ErrorAction SilentlyContinue
# Disable mouse hover time
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseHoverTime' -Value '0' -Type String -ErrorAction SilentlyContinue
Write-Host "  Done." -ForegroundColor Green

Write-Host "`n=== ALL FIXES APPLIED ===" -ForegroundColor Cyan
Write-Host "Restart Windows for all changes to take full effect." -ForegroundColor Yellow
Write-Host ""
Write-Host "If mouse still lags after restart, download the latest ELAN driver from" -ForegroundColor Yellow
Write-Host "your laptop manufacturer's support site (the current one is from 2019)." -ForegroundColor Yellow
