# WSL VHDX Compact Script
# Run this in PowerShell as Administrator on Windows

Write-Host "=== WSL VHDX COMPACT ===" -ForegroundColor Green

# Step 1: Shutdown WSL
Write-Host "`n1. Shutting down WSL..." -ForegroundColor Yellow
wsl --shutdown
Start-Sleep -Seconds 3

# Step 2: Find VHDX
$vhdxPath = Get-ChildItem "$env:LOCALAPPDATA\Packages" -Recurse -Filter "ext4.vhdx" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $vhdxPath) {
    # Try alternative locations
    $vhdxPath = Get-ChildItem "C:\Users\$env:USERNAME\AppData\Local\Docker" -Recurse -Filter "*.vhdx" -ErrorAction SilentlyContinue | Select-Object -First 1
}

if ($vhdxPath) {
    Write-Host "   Found: $($vhdxPath.FullName)" -ForegroundColor Cyan
    $beforeSize = [math]::Round($vhdxPath.Length/1GB, 2)
    Write-Host "   Current size: ${beforeSize} GB" -ForegroundColor Cyan

    # Step 3: Compact
    Write-Host "`n2. Compacting VHDX..." -ForegroundColor Yellow
    Optimize-VHD -Path $vhdxPath.FullName -Mode Full

    $afterSize = [math]::Round($vhdxPath.Length/1GB, 2)
    Write-Host "   After compact: ${afterSize} GB" -ForegroundColor Cyan
    Write-Host "   Freed: $([math]::Round($beforeSize - $afterSize, 2)) GB" -ForegroundColor Green
} else {
    Write-Host "   VHDX not found. WSL may use a different storage method." -ForegroundColor Red
}

# Step 4: Restart WSL
Write-Host "`n3. Restarting WSL..." -ForegroundColor Yellow
wsl -d Ubuntu

Write-Host "`n=== DONE ===" -ForegroundColor Green
