# Apply ALL available fixes without admin rights
# This covers everything in HKCU plus some services

Write-Host "Applying all non-admin fixes..."

# Mouse
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseXCurve' -Value ([byte[]](0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC0,0xCC,0x0C,0x00,0x00,0x00,0x00,0x00,0x80,0x99,0x19,0x00,0x00,0x00,0x00,0x00,0x40,0x66,0x26,0x00,0x00,0x00,0x00,0x00,0x00,0x33,0x33,0x00,0x00,0x00,0x00,0x00)) -Type Binary
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseYCurve' -Value ([byte[]](0x00,0x00,0x38,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x70,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xA8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE4,0xBE,0x92,0x00,0x00,0x00)) -Type Binary
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSpeed' -Value '1'
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold1' -Value '6'
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold2' -Value '10'
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSensitivity' -Value '10'
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseTrails' -Value '0'
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'ActiveWindowTracking' -Value 0 -Type DWord
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseHoverTime' -Value '0'
Write-Host "[OK] Mouse settings"

# Keyboard
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardDelay' -Value '0'
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardSpeed' -Value '31'
Write-Host "[OK] Keyboard settings"

# Desktop
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '0'
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1'
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'HungAppTimeout' -Value '1000'
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillAppTimeout' -Value '2000'
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x90,0x12,0x03,0x80,0x10,0x00,0x00,0x00)) -Type Binary
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 1000 -Type DWord
Write-Host "[OK] Desktop responsiveness"

# Visual effects
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name 'VisualFXSetting' -Value 2 -Type DWord -ErrorAction SilentlyContinue
Write-Host "[OK] Visual effects"

# Disable Windows Search indexing (reduces background overhead)
Get-Service WSearch -ErrorAction SilentlyContinue | Stop-Service -Force -ErrorAction SilentlyContinue
Set-Service WSearch -StartupType Disabled -ErrorAction SilentlyContinue
Write-Host "[OK] Windows Search disabled (reduces background overhead)"

# Disable SysMain (Superfetch) - can cause disk thrashing
Get-Service SysMain -ErrorAction SilentlyContinue | Stop-Service -Force -ErrorAction SilentlyContinue
Set-Service SysMain -StartupType Disabled -ErrorAction SilentlyContinue
Write-Host "[OK] SysMain disabled"

# Disable Windows Update auto-restart (prevents sudden background activity)
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'EnableStartMenu' -Value 1 -Type DWord -ErrorAction SilentlyContinue

# Disable mouse wheel scroll delta issues
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'WheelScrollLines' -Value '3' -Type String -ErrorAction SilentlyContinue

Write-Host "`nAll non-admin fixes applied!"
Write-Host "Restart Windows for full effect."
