$driver = Get-CimInstance -ClassName Win32_PnPSignedDriver | Where-Object { $_.DeviceName -match 'ELAN|TouchPad|I2C' }
if ($driver) {
    $driver | ForEach-Object {
        Write-Host "Device: $($_.DeviceName)"
        Write-Host "Driver: $($_.DriverVersion)"
        Write-Host "Date: $($_.DriverDate)"
        Write-Host "INF: $($_.InfName)"
    }
} else {
    Write-Host "No ELAN/TouchPad/I2C drivers found"
}

Write-Host "---"
$devices = Get-PnpDevice -Class Mouse,Keyboard -Status OK,Error,Degraded
$devices | ForEach-Object {
    Write-Host "$($_.Status) $($_.Class) $($_.FriendlyName)"
}
