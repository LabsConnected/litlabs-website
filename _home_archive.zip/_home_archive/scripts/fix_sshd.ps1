
$ErrorActionPreference = "SilentlyContinue"

# Backup config
Copy-Item C:\ProgramData\ssh\sshd_config C:\ProgramData\ssh\sshd_config.bak -Force

# Write clean minimal config
@"
Port 22
ListenAddress 0.0.0.0
HostKey C:/ProgramData/ssh/ssh_host_rsa_key
HostKey C:/ProgramData/ssh/ssh_host_ecdsa_key
HostKey C:/ProgramData/ssh/ssh_host_ed25519_key
PubkeyAuthentication yes
PasswordAuthentication yes
PermitRootLogin no
"@ | Set-Content C:\ProgramData\ssh\sshd_config -Encoding UTF8

# Test config
& "C:\Windows\System32\OpenSSH\sshd.exe" -t
$configOk = $LASTEXITCODE -eq 0

# Start service
Start-Service sshd -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3
$svc = Get-Service sshd

# Output results for capture
Write-Output "CONFIG_TEST: $configOk"
Write-Output "SERVICE_STATUS: $($svc.Status)"

# Check port
$listeners = Get-NetTCPConnection -LocalPort 22 -State Listen -ErrorAction SilentlyContinue
Write-Output "PORT_22_LISTENING: $($listeners -ne $null)"
