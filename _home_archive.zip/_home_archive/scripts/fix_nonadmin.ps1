# Non-admin fixes (no elevation needed)

Write-Host "=== Applying non-admin input fixes ===" -ForegroundColor Cyan

# 1. Mouse acceleration curves
Write-Host "`n[1/5] Mouse acceleration curves..." -ForegroundColor Yellow
$XC = [byte[]](0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC0,0xCC,0x0C,0x00,0x00,0x00,0x00,0x00,0x80,0x99,0x19,0x00,0x00,0x00,0x00,0x00,0x40,0x66,0x26,0x00,0x00,0x00,0x00,0x00,0x00,0x33,0x33,0x00,0x00,0x00,0x00,0x00)
$YC = [byte[]](0x00,0x00,0x38,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x70,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xA8,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xE4,0xBE,0x92,0x00,0x00,0x00)
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseXCurve' -Value $XC -Type Binary -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'CursorSmoothMouseYCurve' -Value $YC -Type Binary -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSpeed' -Value '1' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold1' -Value '6' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseThreshold2' -Value '10' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseSensitivity' -Value '10' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseTrails' -Value '0' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'ActiveWindowTracking' -Value 0 -Type DWord
Write-Host "  Done." -ForegroundColor Green

# 2. Keyboard speed
Write-Host "`n[2/5] Keyboard response speed..." -ForegroundColor Yellow
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardDelay' -Value '0' -Type String
Set-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'KeyboardSpeed' -Value '31' -Type String
Write-Host "  Done." -ForegroundColor Green

# 3. Desktop responsiveness
Write-Host "`n[3/5] Desktop responsiveness..." -ForegroundColor Yellow
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'MenuShowDelay' -Value '0' -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'AutoEndTasks' -Value '1' -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'HungAppTimeout' -Value '1000' -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'WaitToKillAppTimeout' -Value '2000' -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'LowLevelHooksTimeout' -Value 1000 -Type DWord -ErrorAction SilentlyContinue
Write-Host "  Done." -ForegroundColor Green

# 4. Mouse hover time
Write-Host "`n[4/5] Mouse hover optimization..." -ForegroundColor Yellow
Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'MouseHoverTime' -Value '0' -Type String -ErrorAction SilentlyContinue
Write-Host "  Done." -ForegroundColor Green

# 5. Disable Windows visual effects that cause input lag
Write-Host "`n[5/5] Reducing visual effects for responsiveness..." -ForegroundColor Yellow
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'UserPreferencesMask' -Value ([byte[]](0x90,0x12,0x03,0x80,0x10,0x00,0x00,0x00)) -Type Binary -ErrorAction SilentlyContinue
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name 'VisualFXSetting' -Value 2 -Type DWord -ErrorAction SilentlyContinue
Write-Host "  Done." -ForegroundColor Green

Write-Host "`n=== ALL NON-ADMIN FIXES APPLIED ===" -ForegroundColor Cyan
Write-Host "Some fixes (USB selective suspend, driver power management) need admin rights." -ForegroundColor Yellow
Write-Host "You'll get a UAC prompt to apply those when you run the elevated script." -ForegroundColor Yellow
