# Get laptop model and hardware info
$cs = Get-CimInstance -ClassName Win32_ComputerSystem
Write-Host "Manufacturer: $($cs.Manufacturer)"
Write-Host "Model: $($cs.Model)"
Write-Host "System: $($cs.SystemFamily)"
Write-Host "BIOS: $($cs.BIOSVersion)"

Write-Host ""
$baseboard = Get-CimInstance -ClassName Win32_BaseBoard
Write-Host "Baseboard: $($baseboard.Manufacturer) $($baseboard.Product)"

Write-Host ""
$mouse = Get-CimInstance -ClassName Win32_PointingDevice
$mouse | ForEach-Object {
    Write-Host "Mouse: $($_.Name) - $($_.Manufacturer) - $($_.HardwareType)"
}

Write-Host ""
$kb = Get-CimInstance -ClassName Win32_Keyboard
$kb | ForEach-Object {
    Write-Host "Keyboard: $($_.Name) - $($_.Manufacturer)"
}

Write-Host ""
# Check for OEM driver packages
$drivers = Get-CimInstance -ClassName Win32_PnPSignedDriver | Where-Object { $_.DeviceName -match 'ELAN|Synaptics|Touch|Pointing|Mouse' }
$drivers | ForEach-Object {
    Write-Host "Driver: $($_.DeviceName) v$($_.DriverVersion) ($($_.DriverDate)) - $($_.InfName)"
}
