@echo off
echo ========================================
echo MEMORY CLEANUP UTILITY
echo ========================================
echo.
echo Current RAM usage before cleanup:
powershell "$os = Get-CimInstance Win32_OperatingSystem; Write-Host ('Total: ' + [math]::Round($os.TotalVisibleMemorySize/1MB,2) + 'GB | Free: ' + [math]::Round($os.FreePhysicalMemory/1MB,2) + 'GB | Used: ' + [math]::Round((($os.TotalVisibleMemorySize - $os.FreePhysicalMemory)/$os.TotalVisibleMemorySize)*100,1) + '%%')"
echo.
echo Closing duplicate instances...
echo.
echo [1/4] Killing extra Devin instances (keeping newest)...
powershell "Get-Process Devin -ErrorAction SilentlyContinue | Sort-Object StartTime -Descending | Select-Object -Skip 1 | Stop-Process -Force" 2>nul
echo Done.
echo.
echo [2/4] Closing duplicate Firefox instances (keeping newest)...
powershell "Get-Process firefox -ErrorAction SilentlyContinue | Sort-Object StartTime -Descending | Select-Object -Skip 1 | Stop-Process -Force" 2>nul
echo Done.
echo.
echo [3/4] Cleaning up duplicate Cline instances...
powershell "Get-Process cline -ErrorAction SilentlyContinue | Sort-Object StartTime -Descending | Select-Object -Skip 1 | Stop-Process -Force" 2>nul
echo Done.
echo.
echo [4/4] Stopping Plex if not actively using it...
powershell "Stop-Process -Name 'Plex Media Server' -Force -ErrorAction SilentlyContinue" 2>nul
echo Done.
echo.
echo Clearing standby memory...
powershell "Clear-RecycleBin -Force -ErrorAction SilentlyContinue; [System.GC]::Collect()" 2>nul
echo Done.
echo.
echo ========================================
echo RAM usage after cleanup:
powershell "$os = Get-CimInstance Win32_OperatingSystem; Write-Host ('Total: ' + [math]::Round($os.TotalVisibleMemorySize/1MB,2) + 'GB | Free: ' + [math]::Round($os.FreePhysicalMemory/1MB,2) + 'GB | Used: ' + [math]::Round((($os.TotalVisibleMemorySize - $os.FreePhysicalMemory)/$os.TotalVisibleMemorySize)*100,1) + '%%')"
echo ========================================
echo.
echo You should now have 3-5GB more free RAM!
echo.
pause
