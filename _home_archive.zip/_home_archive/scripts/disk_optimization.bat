@echo off
chcp 65001 >nul
echo ========================================
echo DISK & STORAGE OPTIMIZATION
echo ========================================
echo.
echo Optimizing NVMe SSD...
echo.
echo [1/3] Running TRIM on NVMe drive (C:)...
powershell "Optimize-Volume -DriveLetter C -ReTrim -Verbose" 2>&1 | findstr /V "^$"
echo Done.
echo.
echo [2/3] Optimizing Crucial SSD...
powershell "Optimize-Volume -DriveLetter E -ReTrim -Verbose" 2>&1 | findstr /V "^$"
echo Done.
echo.
echo [3/3] Checking disk health...
powershell "Get-PhysicalDisk | Select-Object FriendlyName,MediaType,HealthStatus,Size | Format-Table -AutoSize"
echo.
echo ========================================
echo Disk optimization complete!
echo ========================================
echo.
echo Tip: Run this monthly for best performance
echo.
pause
