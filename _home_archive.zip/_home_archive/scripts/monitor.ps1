Write-Host '==== SYSTEM MONITOR ===='
Write-Host ''
Write-Host 'MEMORY:'
Get-CimInstance Win32_OperatingSystem | Select TotalVisibleMemorySize,FreePhysicalMemory
Write-Host ''
Write-Host 'CPU LOAD:'
Get-CimInstance Win32_Processor | Select LoadPercentage
Write-Host ''
Write-Host 'TOP MEMORY PROCESSES:'
Get-Process | Sort WorkingSet64 -Descending | Select -First 15 ProcessName,Id,@{Name='MemoryMB';Expression={[math]::Round($_.WorkingSet64/1MB,1)}}
