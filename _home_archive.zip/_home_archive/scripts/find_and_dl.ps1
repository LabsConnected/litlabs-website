# Try to find and install ELAN driver via multiple methods

# Method 1: Check if Acer Care Center can find it
Write-Host "=== Method 1: Acer Care Center ==="
try {
    $acerApps = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" | Where-Object { $_.DisplayName -match 'Acer' }
    $acerApps | ForEach-Object { Write-Host "  Found: $($_.DisplayName)" }
} catch {}

# Method 2: Try to download from Acer's CDN directly
Write-Host "`n=== Method 2: Acer CDN ==="
$headers = @{ "User-Agent" = "Mozilla/5.0" }

# Known Acer CDN patterns for Nitro 5 AN515-54 drivers
$cdnUrls = @(
    "https://global-download.acer.com/OSDriver/ELAN_I2C/13.6.14.1/ELAN_I2C.zip",
    "https://global-download.acer.com/OSDriver/TouchPad/ELAN/13.6.14.1/ELAN.zip",
    "https://global-download.acer.com/gdf/ELAN_I2C/13.6.14.1/ELAN_I2C.zip"
)

foreach ($url in $cdnUrls) {
    try {
        $resp = Invoke-WebRequest -Uri $url -Headers $headers -UseBasicParsing -TimeoutSec 10
        if ($resp.StatusCode -eq 200 -and $resp.Content.Length -gt 1000) {
            $out = "C:\Users\litbi\acer_elan.zip"
            [System.IO.File]::WriteAllBytes($out, $resp.Content)
            Write-Host "  DOWNLOADED: $url -> $out ($([math]::Round($resp.Content.Length/1KB, 0)) KB)"
        } else {
            Write-Host "  Skip: $url (status=$($resp.StatusCode), size=$($resp.Content.Length))"
        }
    } catch {
        Write-Host "  Fail: $url - $($_.Exception.Message)"
    }
}

# Method 3: Use Windows Update to find driver
Write-Host "`n=== Method 3: Windows Update ==="
try {
    $us = New-Object -ComObject Microsoft.Update.Session
    $sr = $us.CreateUpdateSearcher()
    $res = $sr.Search("IsInstalled=0 and Type='Driver'")
    $allDrivers = @($res.Updates | ForEach-Object { $_.Title })
    Write-Host "  Available driver updates: $($allDrivers.Count)"
    $allDrivers | ForEach-Object { Write-Host "    $_" }
} catch {
    Write-Host "  Error: $_"
}

# Method 4: Check for driver in DriverStore
Write-Host "`n=== Method 4: Driver Store ==="
$drivers = Get-ChildItem "C:\Windows\System32\DriverStore\FileRepository" | Where-Object { $_.Name -match 'elan|touch|i2c' }
if ($drivers) {
    $drivers | ForEach-Object { Write-Host "  Found: $($_.Name)" }
} else {
    Write-Host "  No ELAN/touchpad drivers in DriverStore"
}

# Method 5: Use pnputil to list OEM drivers
Write-Host "`n=== Method 5: PnPUtil ==="
$pnputil = & pnputil /enum-drivers 2>&1
$elanLines = $pnputil | Select-String -Pattern "ELAN|TouchPad|touch" -Context 0,3
if ($elanLines) {
    $elanLines | ForEach-Object { Write-Host "  $($_.Line)" }
} else {
    Write-Host "  No ELAN drivers found via pnputil"
}
