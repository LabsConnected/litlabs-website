# === ADMIN INPUT FIX — Acer Nitro 5 AN515-54 ===
# Run as: Right-click → "Run with PowerShell" (accept UAC)

Write-Host "=== Admin Input Fix ===" -ForegroundColor Cyan

# 1. Disable USB selective suspend
Write-Host "[1/3] Disabling USB selective suspend..." -ForegroundColor Yellow
powercfg /setacvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0
powercfg /setdcvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0
powercfg /setactive scheme_current
Write-Host "  Done." -ForegroundColor Green

# 2. Disable power management on all mouse + keyboard devices
Write-Host "[2/3] Disabling power management on input devices..." -ForegroundColor Yellow
Get-PnpDevice -Class Mouse,Keyboard -Status OK -ErrorAction SilentlyContinue | ForEach-Object {
    $p = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters"
    if (Test-Path $p) {
        Set-ItemProperty -Path $p -Name "EnhancedPowerManagementEnabled" -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path $p -Name "SelectiveSuspendEnabled"        -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path $p -Name "AllowIdleIrpInD3"               -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path $p -Name "D3ColdSupported"                -Value 0 -ErrorAction SilentlyContinue
        Write-Host "  OK: $($_.FriendlyName)" -ForegroundColor Gray
    }
}
Write-Host "  Done." -ForegroundColor Green

# 3. Download latest ELAN driver from Acer via their API
Write-Host "[3/3] Fetching latest ELAN driver for Acer Nitro 5 AN515-54..." -ForegroundColor Yellow
$outDir = "$env:USERPROFILE\Downloads\ELAN_Driver"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

# Acer's actual driver list API
try {
    $resp = Invoke-RestMethod -Uri "https://www.acer.com/ac/US-en/content/support-product/AN515-54?tab=drivers" `
        -Headers @{"User-Agent"="Mozilla/5.0"} -TimeoutSec 20
    Write-Host "  Acer page fetched." -ForegroundColor Gray
} catch { Write-Host "  Acer fetch failed: $_" -ForegroundColor Red }

# Known direct driver URLs from Acer CDN for this model
$driverUrls = @(
    "https://global-download.acer.com/OSDriver/ELAN_I2C/16.0.3.3/ELAN_I2C.zip",
    "https://global-download.acer.com/OSDriver/ELAN_I2C/15.12.3.2/ELAN_I2C.zip",
    "https://global-download.acer.com/OSDriver/TouchPad_ELAN/16.0.3.3/TouchPad_ELAN.zip"
)
$downloaded = $false
foreach ($url in $driverUrls) {
    try {
        $file = "$outDir\elan_driver.zip"
        Invoke-WebRequest -Uri $url -OutFile $file -TimeoutSec 30 -ErrorAction Stop
        if ((Get-Item $file).Length -gt 10000) {
            Write-Host "  Downloaded: $url" -ForegroundColor Green
            Expand-Archive -Path $file -DestinationPath "$outDir\extracted" -Force
            Write-Host "  Extracted to: $outDir\extracted" -ForegroundColor Green
            $downloaded = $true
            break
        }
    } catch { continue }
}

if (-not $downloaded) {
    Write-Host ""
    Write-Host "  Auto-download failed. Open this URL in your browser:" -ForegroundColor Yellow
    Write-Host "  https://www.acer.com/ac/US-en/content/support-product/AN515-54" -ForegroundColor Cyan
    Write-Host "  Filter by: Touchpad Driver — install anything newer than 13.6.14.1 (2019)" -ForegroundColor Cyan
    Start-Process "https://www.acer.com/ac/US-en/content/support-product/AN515-54"
}

Write-Host ""
Write-Host "=== DONE. Restart Windows now. ===" -ForegroundColor Cyan
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
