@echo off
REM Windows Cleanup Script - Double-click to run as Admin
REM If prompted, click "Yes" to allow admin access

setlocal enabledelayedexpansion

echo.
echo ════════════════════════════════════════
echo   WINDOWS CLEANUP SCRIPT
echo ════════════════════════════════════════
echo.

REM Check admin rights
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo ERROR: This script must run as Administrator.
    echo Please right-click this file and select "Run as administrator"
    pause
    exit /b 1
)

echo [1/5] Cleaning Windows Temp folder...
cd /d %TEMP%
del /q /s * >nul 2>&1
echo   ✓ Temp cleared

echo.
echo [2/5] Cleaning System Temp...
cd /d C:\Windows\Temp
del /q /s * >nul 2>&1
echo   ✓ System temp cleared

echo.
echo [3/5] Cleaning Windows Update cache...
net stop wuauserv >nul 2>&1
del /q /s C:\Windows\SoftwareDistribution\Download\* >nul 2>&1
net start wuauserv >nul 2>&1
echo   ✓ WU cache cleared

echo.
echo [4/5] Emptying Recycle Bin...
RD /S /Q "%systemdrive%\$Recycle.bin" >nul 2>&1
echo   ✓ Recycle bin emptied

echo.
echo [5/5] Disabling Hibernation (frees 5-15GB)...
powercfg /hibernate off >nul 2>&1
echo   ✓ Hibernation disabled

echo.
echo ════════════════════════════════════════
echo   CLEANUP COMPLETE
echo ════════════════════════════════════════
echo.
echo Your system should now be faster and have more disk space.
echo.
pause
