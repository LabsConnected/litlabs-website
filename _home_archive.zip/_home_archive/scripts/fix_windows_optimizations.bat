@echo off
chcp 65001 >nul
echo ========================================
echo WINDOWS OPTIMIZATION FIXES
echo ========================================
echo.
echo [1/5] Enabling Prefetch (Application Pre-loading)...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnablePrefetcher /t REG_DWORD /d 3 /f >nul 2>&1
echo Done.
echo.
echo [2/5] Enabling Superfetch (Memory Management)...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnableSuperfetch /t REG_DWORD /d 3 /f >nul 2>&1
echo Done.
echo.
echo [3/5] Disabling unnecessary startup programs...
echo.
echo Removing duplicate GoogleDriveFS...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "GoogleDriveFS" /f >nul 2>&1
echo Done.
echo.
echo Removing duplicate OneDriveSetup...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "OneDriveSetup" /f >nul 2>&1
echo Done.
echo.
echo [4/5] Optimizing visual effects for performance...
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c >nul 2>&1
echo Done.
echo.
echo [5/5] Disabling unnecessary visual effects...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f >nul 2>&1
echo Done.
echo.
echo ========================================
echo All optimizations applied!
echo ========================================
echo.
echo IMPORTANT: Restart your computer for all changes to take full effect.
echo.
pause
