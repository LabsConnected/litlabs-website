﻿$config = @"
Port 2222
PasswordAuthentication yes
PubkeyAuthentication yes
Subsystem sftp sftp-server.exe
StrictModes no
Match Group administrators
    AuthorizedKeysFile __PROGRAMDATA__/ssh/administrators_authorized_keys
"@
$config | Out-File -FilePath 'C:\ProgramData\ssh\sshd_config' -Encoding ASCII -Force

if (-not (Test-Path 'C:\ProgramData\ssh\administrators_authorized_keys')) {
    New-Item -Path 'C:\ProgramData\ssh\administrators_authorized_keys' -ItemType File -Force
}

icacls "C:\ProgramData\ssh\administrators_authorized_keys" /inheritance:r /grant "SYSTEM:(R)" /grant "BUILTIN\Administrators:(R)" /T
Restart-Service sshd
