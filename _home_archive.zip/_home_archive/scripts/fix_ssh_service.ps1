#Requires -RunAsAdministrator
# Fix OpenSSH so it runs as a Windows service instead of opening a terminal at login.

# Sanity check: must be running as admin.
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "This script must be run as Administrator." -ForegroundColor Red
    exit 1
}

Start-Transcript -Path "C:\Users\litbi\sshd_fix.log" -Force | Out-Null

# Remove the startup batch file that opens the terminal window.
$startupBatch = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\sshd.bat"
if (Test-Path $startupBatch) {
    Remove-Item $startupBatch -Force
    Write-Host "Removed startup batch file: $startupBatch" -ForegroundColor Green
}

# Make sure the OpenSSH Server optional feature is installed.
try {
    $cap = Get-WindowsCapability -Online -Name "OpenSSH.Server~~~~0.0.1.0" -ErrorAction Stop
    if ($cap.State -ne 'Installed') {
        Write-Host "Installing OpenSSH Server Windows capability..." -ForegroundColor Cyan
        Add-WindowsCapability -Online -Name "OpenSSH.Server~~~~0.0.1.0" -ErrorAction Stop | Out-Null
    } else {
        Write-Host "OpenSSH Server capability is already installed." -ForegroundColor Green
    }
} catch {
    Write-Host "Could not install OpenSSH capability (may be offline or already present): $_" -ForegroundColor Yellow
}

# Reinstall the sshd service with the correct service account.
Write-Host "Reinstalling sshd service with account NT SERVICE\SSHD..." -ForegroundColor Cyan
sc.exe stop sshd | Out-Null
sc.exe delete sshd | Out-Null
$createResult = sc.exe create sshd binPath= "C:\Windows\System32\OpenSSH\sshd.exe" start= auto obj= "NT SERVICE\SSHD" DisplayName= "OpenSSH SSH Server"
Write-Host "sc.exe create result: $createResult"
sc.exe description sshd "OpenSSH SSH Server" | Out-Null

# Ensure host keys exist.
& "C:\Windows\System32\OpenSSH\ssh-keygen.exe" -A

# Fix host key ownership and permissions. The service runs as NT SERVICE\SSHD,
# so that account must own the keys and have exclusive access.
$keyFiles = @(
    "C:\ProgramData\ssh\ssh_host_rsa_key",
    "C:\ProgramData\ssh\ssh_host_ecdsa_key",
    "C:\ProgramData\ssh\ssh_host_ed25519_key"
)
foreach ($key in $keyFiles) {
    if (Test-Path $key) {
        takeown /F $key /A | Out-Null
        icacls $key /setowner "NT SERVICE\SSHD" | Out-Null
        # Strip every permission except the service account, SYSTEM, and Administrators.
        # OpenSSH refuses to start if any other user can read the private key.
        $acl = Get-Acl $key
        $acl.Access | Where-Object { $_.IdentityReference -notmatch 'NT SERVICE\\SSHD|SYSTEM|Administrators' } | ForEach-Object { $acl.RemoveAccessRule($_) | Out-Null }
        $acl.SetAccessRuleProtection($true, $false)
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("NT SERVICE\SSHD", "FullControl", "Allow")))
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("NT AUTHORITY\SYSTEM", "FullControl", "Allow")))
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule("BUILTIN\Administrators", "FullControl", "Allow")))
        Set-Acl $key $acl
        Write-Host "Fixed owner and permissions for $key" -ForegroundColor Green
    }
}

# Make the SSH logs folder readable by admins so we can diagnose failures.
if (Test-Path "C:\ProgramData\ssh\logs") {
    takeown /F "C:\ProgramData\ssh\logs" /A /R /D Y | Out-Null
    icacls "C:\ProgramData\ssh\logs" /grant:r "Administrators:F" /T | Out-Null
}

# Detect port 22 conflict. A WSL port proxy is already listening on 22,
# so we move Windows sshd to port 2222 to avoid fighting it.
$listener = Get-NetTCPConnection -LocalPort 22 -ErrorAction SilentlyContinue | Where-Object { $_.State -eq 'Listen' }
$sshPort = 22
if ($listener) {
    $listenerPid = $listener.OwningProcess
    $procName = (Get-Process -Id $listenerPid -ErrorAction SilentlyContinue).Name
    Write-Host "Port 22 is already in use by PID $listenerPid ($procName). Moving Windows sshd to port 2222..." -ForegroundColor Yellow
    $config = Get-Content "C:\ProgramData\ssh\sshd_config"
    if ($config -match '^Port\s+\d+\s*$') {
        $config = $config -replace '^Port\s+\d+\s*$', 'Port 2222'
    } else {
        $config = @("Port 2222") + $config
    }
    $config | Set-Content "C:\ProgramData\ssh\sshd_config" -Encoding UTF8
    $sshPort = 2222
}

# Grant the "Log on as a service" right to the NT SERVICE\SSHD account.
# Without this right, Windows refuses to start the sshd service.
$svcSid = (New-Object System.Security.Principal.NTAccount("NT SERVICE\SSHD")).Translate([System.Security.Principal.SecurityIdentifier]).Value
$infPath = "C:\Users\litbi\secpol.inf"
$seceditDb = "$env:TEMP\secedit.sdb"
Write-Host "Granting 'Log on as a service' right to NT SERVICE\SSHD ($svcSid)..." -ForegroundColor Cyan
secedit /export /cfg $infPath /areas USER_RIGHTS | Out-Null
$inf = Get-Content $infPath
$privLine = $inf | Where-Object { $_ -match '^SeServiceLogonRight\s*=' }
if ($privLine) {
    if ($privLine -notmatch [regex]::Escape($svcSid)) {
        $newPrivLine = "$privLine,*$svcSid"
        $inf = $inf -replace [regex]::Escape($privLine), $newPrivLine
        $inf | Set-Content $infPath -Encoding Unicode
        secedit /configure /db $seceditDb /cfg $infPath /areas USER_RIGHTS | Out-Null
        Write-Host "Granted 'Log on as a service' right." -ForegroundColor Green
    } else {
        Write-Host "'Log on as a service' right already granted." -ForegroundColor Green
    }
} else {
    Add-Content $infPath -Value "`n[Privilege Rights]`nSeServiceLogonRight = *$svcSid" -Encoding Unicode
    secedit /configure /db $seceditDb /cfg $infPath /areas USER_RIGHTS | Out-Null
    Write-Host "Granted 'Log on as a service' right." -ForegroundColor Green
}

# Configure ssh-agent.
Set-Service ssh-agent -StartupType Automatic
Start-Service ssh-agent -ErrorAction SilentlyContinue

# Test the configuration before starting the service.
Write-Host "Testing sshd configuration..." -ForegroundColor Cyan
& "C:\Windows\System32\OpenSSH\sshd.exe" -t -f "C:\ProgramData\ssh\sshd_config"

# Start sshd.
Start-Service sshd
Set-Service sshd -StartupType Automatic

# Allow inbound SSH through the firewall on the chosen port.
$fwRuleName = "OpenSSH Server"
$existing = Get-NetFirewallRule -Name $fwRuleName -ErrorAction SilentlyContinue
if (-not $existing) {
    New-NetFirewallRule -Name $fwRuleName -DisplayName $fwRuleName -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort $sshPort | Out-Null
    Write-Host "Added firewall rule for OpenSSH Server on port $sshPort" -ForegroundColor Green
} elseif ($sshPort -ne 22) {
    Get-NetFirewallPortFilter -AssociatedNetFirewallRule $existing | Set-NetFirewallPortFilter -LocalPort $sshPort
    Write-Host "Updated firewall rule to port $sshPort" -ForegroundColor Green
}

$sshdStatus = (Get-Service sshd).Status
Write-Host ""
Write-Host "OpenSSH SSH Server status: $sshdStatus" -ForegroundColor Cyan
if ($sshdStatus -eq 'Running') {
    Write-Host "SSH is now running as a service on port $sshPort. The startup terminal window will no longer appear." -ForegroundColor Green
    if ($sshPort -eq 2222) {
        Write-Host "WSL is already using port 22, so Windows SSH is on port 2222. Connect with: ssh -p 2222 user@this-pc" -ForegroundColor Cyan
    }
} else {
    Write-Host "sshd did not start. Running debug capture..." -ForegroundColor Yellow
    $debugLog = "C:\Users\litbi\sshd_debug.log"
    Remove-Item $debugLog -ErrorAction SilentlyContinue
    $job = Start-Job -ScriptBlock {
        $env:PATH = "C:\Windows\System32\OpenSSH;$env:PATH"
        & "C:\Windows\System32\OpenSSH\sshd.exe" -d -f "C:\ProgramData\ssh\sshd_config" 2>&1
    }
    Start-Sleep -Seconds 5
    Stop-Job $job
    Receive-Job $job | Out-File $debugLog -Append
    Remove-Job $job
    Write-Host "Debug output saved to $debugLog" -ForegroundColor Yellow
    if (Test-Path $debugLog) {
        Get-Content $debugLog -Tail 30
    }
}

Stop-Transcript | Out-Null
