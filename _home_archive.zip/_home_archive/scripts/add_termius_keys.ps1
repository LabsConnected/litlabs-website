#Requires -RunAsAdministrator
$keys = @(
    'sk-ecdsa-sha2-nistp256@openssh.com AAAAInNrLWVjZHNhLXNoYTItbmlzdHAyNTYAAABBBOHptMvpg0WmFHPqaa7errMK4VHzEPxyEeqMrjzzWsLL0sHRiPJU8AEwyQ3wZiy3H/9MUEzGcgm9vZDV/+bdrBkAAAAHVGVybWl1cw== #SSH ID - @litlabs',
    'ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBP8lIgxf6dvUIG+xs5ClraApypAwdMJ59sTTaTr8/68dci/4bsDpATTAWw7B0mSAxALDYjjyBGo2VWNMTjWgkTg= #SSH ID - @litlabs'
)
$file = 'C:\ProgramData\ssh\administrators_authorized_keys'
if (-not (Test-Path $file)) {
    New-Item -ItemType File -Path $file -Force | Out-Null
}
takeown /F $file /A | Out-Null
icacls $file /grant "$env:USERDOMAIN\$env:USERNAME`:F" | Out-Null
foreach ($key in $keys) {
    if (-not (Select-String -Path $file -Pattern [regex]::Escape($key) -Quiet)) {
        Add-Content $file $key
    }
}
icacls $file /inheritance:r | Out-Null
icacls $file /setowner 'NT SERVICE\SSHD' | Out-Null
icacls $file /grant:r 'NT SERVICE\SSHD:F' | Out-Null
icacls $file /remove "$env:USERDOMAIN\$env:USERNAME" | Out-Null
Write-Host 'Termius keys added to administrators_authorized_keys.' -ForegroundColor Green
