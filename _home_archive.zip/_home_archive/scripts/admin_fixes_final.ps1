# === ONE-CLICK ADMIN FIX ===
# Save this as admin_fixes.ps1 on your Desktop
# Right-click it → "Run with PowerShell" (as Admin)

Write-Host "=== Admin Input Fixes ===" -ForegroundColor Cyan

# 1. Disable USB selective suspend
Write-Host "`n[1/4] Disabling USB selective suspend..." -ForegroundColor Yellow
powercfg /setacvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0
powercfg /setdcvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb80f7e616 0
powercfg /setactive scheme_current
Write-Host "  Done." -ForegroundColor Green

# 2. Disable power management on all input devices
Write-Host "`n[2/4] Disabling power management on input devices..." -ForegroundColor Yellow
Get-PnpDevice -Class Mouse,Keyboard -Status OK -ErrorAction SilentlyContinue | ForEach-Object {
    $p = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters"
    Set-ItemProperty -Path $p -Name "EnhancedPowerManagementEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $p -Name "SelectiveSuspendEnabled" -Value 0 -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $p -Name "AllowIdleIrpInD3" -Value 0 -ErrorAction SilentlyContinue
    Write-Host "  $($_.FriendlyName)" -ForegroundColor Gray
}
Write-Host "  Done." -ForegroundColor Green

# 3. Import HKLM registry keys
Write-Host "`n[3/4] Applying HKLM registry keys..." -ForegroundColor Yellow
reg import C:\Users\litbi\input_fixes_hklm.reg
Write-Host "  Done." -ForegroundColor Green

# 4. Check Windows Update for ELAN driver
Write-Host "`n[4/4] Checking for ELAN driver update..." -ForegroundColor Yellow
try {
    $us = New-Object -ComObject Microsoft.Update.Session
    $sr = $us.CreateUpdateSearcher()
    $res = $sr.Search("IsInstalled=0 and Type='Driver'")
    $elan = $res.Updates | Where-Object { $_.Title -match 'ELAN|Touchpad|Synaptics|Pointing' }
    if ($elan) {
        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
        $elan | ForEach-Object { $coll.Add($_) | Out-Null }
        $dl = $us.CreateUpdateDownloader(); $dl.Updates = $coll; $dl.Download() | Out-Null
        $inst = $us.CreateUpdateInstaller(); $inst.Updates = $coll; $r = $inst.Install()
        Write-Host "  Install result: $($r.ResultCode)" -ForegroundColor Green
    } else {
        Write-Host "  No ELAN driver update found." -ForegroundColor Gray
        Write-Host "  Current driver: v13.6.14.1 (2019) - consider downloading from manufacturer." -ForegroundColor Gray
    }
} catch {
    Write-Host "  Could not check: $_" -ForegroundColor Red
}

Write-Host "`n=== ALL ADMIN FIXES APPLIED ===" -ForegroundColor Cyan
Write-Host "Restart Windows now for all changes to take effect." -ForegroundColor Yellow
Write-Host "`nPress any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
