#!/bin/bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && source "$NVM_DIR/nvm.sh"
export PATH="$HOME/bin:$HOME/.local/bin:$PATH"

PROJ="$HOME/LiTTreeLabstudios"
CF_PID="/tmp/cloudflared.pid"
LOG="$PROJ/dev.log"

echo ""
echo "LiTTree Dev Loop -- Mobile"
echo "jarvis.litlabs.net"
echo ""

echo "[1/4] Syncing code from origin..."
cd "$PROJ"
WIP=false
if ! git diff --quiet || ! git diff --cached --quiet; then
  git stash push -m "mobile-wip-$(date +%s)" 2>/dev/null
  WIP=true
fi
git pull --rebase origin main 2>&1 | tail -3
if [ "$WIP" = true ]; then git stash pop 2>/dev/null || true; fi
if git diff --name-only ORIG_HEAD HEAD 2>/dev/null | grep -q 'package.json'; then
  echo "  Installing new deps..."
  npm install --silent
fi
echo "  OK: code is current"

echo ""
echo "[2/4] Killing old dev server..."
pkill -f 'next dev' 2>/dev/null || true
sleep 1

echo ""
echo "[3/4] Starting Cloudflare tunnel..."
if [ -f "$CF_PID" ] && kill -0 "$(cat $CF_PID)" 2>/dev/null; then
  echo "  Tunnel already running (PID $(cat $CF_PID))"
else
  nohup "$HOME/bin/cloudflared" tunnel --config ~/.cloudflared/config.yml run >> /tmp/cloudflared.log 2>&1 &
  echo $! > "$CF_PID"
  sleep 2
  echo "  Tunnel started (PID $(cat $CF_PID))"
fi
echo "  jarvis.litlabs.net  ->  http://127.0.0.1:3000"
echo "  api.litlabs.net     ->  http://127.0.0.1:3000"

echo ""
echo "[4/4] Starting Next.js dev server..."
echo "  Log:  $LOG"
echo "  URL:  https://jarvis.litlabs.net"
echo ""
cd "$PROJ"
npm run dev 2>&1 | tee -a "$LOG"
