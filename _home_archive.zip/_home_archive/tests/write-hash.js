const fs = require('fs');
const hash = '$2b$12$eX1FuOWAsFuqHiFq8XZYl.q0/7R.cy6GZ0/5/PlgaM0TWTuPxiDNW';
fs.writeFileSync('C:\\Users\\litbi\\temp_hash.txt', hash, 'utf8');
console.log('Written:', hash);
console.log('Length:', hash.length);
