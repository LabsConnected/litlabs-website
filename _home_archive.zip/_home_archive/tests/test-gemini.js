const key = 'AIzaSyBQvRdOIz7CIsm8MZ27PuSwwQlJ8UCc2IA';

fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key=' + key, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    contents: [{ role: 'user', parts: [{ text: 'Say hi briefly' }] }],
    generationConfig: { temperature: 0.7, maxOutputTokens: 500 }
  })
})
.then(r => r.json())
.then(d => { if (d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts) { console.log('OK:', d.candidates[0].content.parts[0].text); } else { console.log('Response keys:', Object.keys(d).join(', ')); console.log('Error:', JSON.stringify(d.error || d).substring(0, 200)); } })
.catch(e => console.log('Error:', e.message));
